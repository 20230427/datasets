"""
Extended ProbTS Forecast Module.
Adds normalized MAE and MSE (the values reported in most TSF papers).

ProbTS built-in metrics are computed on raw-scale (denormalized) data:
    - test_MSE → very large numbers (e.g., 10.61 for ETTh1)
    - test_ND  → normalized but by sum of |y|, not standard-scale

Most papers (PatchTST, iTransformer, DLinear, etc.) report MSE/MAE
on StandardScaler-normalized data, yielding values in 0.3-0.5 range.

This module adds:
    - test_norm_MSE: MSE on standardized data
    - test_norm_MAE: MAE on standardized data
"""

import torch
from probts.model.forecast_module import ProbTSForecastModule


class MambaVAEForecastModule(ProbTSForecastModule):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._norm_mse_sum = 0.0
        self._norm_mae_sum = 0.0
        self._norm_count = 0

    def evaluate(self, batch, stage='val', dataloader_idx=0):
        metrics = super().evaluate(batch, stage=stage, dataloader_idx=dataloader_idx)

        batch_data = self.data_manager.preprocess(batch)
        target = batch_data.future_target_cdf
        pred_len = target.shape[1]

        forecasts = self.forecaster.forecast(batch_data, self.num_samples)
        if forecasts is not None:
            forecasts = forecasts[:, :, :pred_len]

            # Point prediction = mean of samples
            pred_mean = forecasts.mean(dim=1)  # [B, pred_len, C]

            # Get scaler parameters to normalize back
            # ProbTS stores scaler info in data_manager
            scaler = getattr(self.data_manager, 'scaler', None)

            if scaler is not None and hasattr(scaler, 'mean') and hasattr(scaler, 'std'):
                # Normalize predictions and targets back to standard scale
                mean = scaler.mean.to(target.device)
                std = scaler.std.to(target.device)
                target_norm = (target - mean) / (std + 1e-8)
                pred_norm = (pred_mean - mean) / (std + 1e-8)
            else:
                # Fallback: the data fed to model is already normalized
                # (past_target_cdf is after scaler transform)
                # Use the model's internal RevIN stats
                target_norm = target
                pred_norm = pred_mean

            norm_mse = torch.mean((pred_norm - target_norm) ** 2).item()
            norm_mae = torch.mean(torch.abs(pred_norm - target_norm)).item()

            prefix = f"{pred_len}_{stage}"
            self.log(f"{prefix}_norm_MSE", norm_mse, prog_bar=False, sync_dist=True)
            self.log(f"{prefix}_norm_MAE", norm_mae, prog_bar=False, sync_dist=True)

        return metrics
