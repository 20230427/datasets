"""
MLP Decoder: latent samples → prediction distribution P(Y|Z).
"""

import torch.nn as nn
import torch.nn.functional as func
from torch.distributions import Normal
from models.blocks import MLP


class MLPDecoder(nn.Module):
    def __init__(self, dynamic_dim, patch_len, n_vars, hidden_dim=256, hidden_layers=3):
        super().__init__()
        out_dim = patch_len * n_vars
        self.decoder_mu = MLP(dynamic_dim, out_dim, hidden_dim, hidden_layers)
        self.decoder_sigma = MLP(dynamic_dim, out_dim, hidden_dim, hidden_layers)
        self.patch_len = patch_len
        self.n_vars = n_vars

    def forward(self, z, step, pred_len, revin_fn=None):
        B = z.shape[0]
        pred_mu = self.decoder_mu(z).reshape(B, step, self.patch_len, self.n_vars)
        pred_mu = pred_mu.reshape(B, -1, self.n_vars)[:, :pred_len, :]

        pred_sigma = self.decoder_sigma(z).reshape(B, step, self.patch_len, self.n_vars)
        pred_sigma = pred_sigma.reshape(B, -1, self.n_vars)[:, :pred_len, :]

        if revin_fn is not None:
            pred_mu = revin_fn(pred_mu, 'denorm')
            pred_sigma = revin_fn(pred_sigma, 'denorm')

        return Normal(loc=pred_mu, scale=func.softplus(pred_sigma) + 1e-6)
