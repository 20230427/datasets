"""
Mamba-VAE Encoder.
Stacked BiMamba blocks producing variational distribution Q(Z|X)
and context reconstruction for L_Rec.
"""

import torch
import torch.nn as nn
import torch.nn.functional as func
from torch.distributions import MultivariateNormal

from models.blocks import BidirectionalMambaBlock, UnidirectionalMambaBlock


class MambaEncoder(nn.Module):
    def __init__(self, d_model, n_layers, freq, step,
                 bidirectional=True, d_state=16, d_conv=4, expand=2, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.freq = freq
        self.step = step

        self.horizon_queries = nn.Parameter(torch.randn(1, step, d_model) * 0.02)
        self.pos_embed = nn.Parameter(torch.randn(1, freq + step, d_model) * 0.02)

        Block = BidirectionalMambaBlock if bidirectional else UnidirectionalMambaBlock
        self.layers = nn.ModuleList([
            Block(d_model, d_state, d_conv, expand, dropout) for _ in range(n_layers)
        ])
        self.norm = nn.LayerNorm(d_model)

        self.mu_head = nn.Linear(d_model, d_model)
        self.logvar_head = nn.Linear(d_model, d_model)
        self.rec_head = nn.Linear(d_model, d_model)

    def forward(self, patches):
        B, n_ctx, D = patches.shape
        S = self.step

        queries = self.horizon_queries.expand(B, -1, -1)
        full_seq = torch.cat([patches, queries], dim=1)
        full_seq = full_seq + self.pos_embed[:, :n_ctx + S, :]

        for layer in self.layers:
            full_seq = layer(full_seq)
        full_seq = self.norm(full_seq)

        context_out = full_seq[:, :n_ctx, :]
        horizon_out = full_seq[:, n_ctx:, :]

        z_mu = self.mu_head(horizon_out)
        z_logvar = torch.clamp(self.logvar_head(horizon_out), min=-10, max=2)

        z_var = func.softplus(z_logvar) + 1e-6
        cov_diag = torch.diag_embed(z_var)
        prior_dist = MultivariateNormal(loc=z_mu, covariance_matrix=cov_diag)

        x_rec_latent = self.rec_head(context_out)

        return z_mu, z_logvar, x_rec_latent, prior_dist
