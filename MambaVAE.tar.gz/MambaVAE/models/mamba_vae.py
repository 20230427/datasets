"""
Mamba-VAE: complete model for probabilistic time series forecasting.

Architecture:
    Encoder: RevIN → Patch → BiMamba blocks → Q(Z|X) + x_rec
    Decoder: z_sample → MLP_mu + MLP_sigma → P(Y|Z) → RevIN denorm

Interface (compatible with ProbTS Forecaster):
    forward(x)              → (x_rec, prior_dist, post_dist)
    sample(x, num_samples)  → [num_samples, B, pred_len, C]
"""

import math
import torch
import torch.nn as nn

from models.blocks import PatchEmbedding, MLP
from models.encoder import MambaEncoder
from models.decoder import MLPDecoder
from models.revin import RevIN


class MambaVAE(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.input_len = config.seq_len
        self.pred_len = config.pred_len
        self.patch_len = config.patch_len
        self.dynamic_dim = config.dynamic_dim
        self.enc_in = config.n_vars

        self.freq = math.ceil(self.input_len / self.patch_len)
        self.step = math.ceil(self.pred_len / self.patch_len)
        self.padding_len = self.patch_len * self.freq - self.input_len

        # Ablation flags
        self.bidirectional = getattr(config, 'bidirectional', True)
        self.use_rec_loss = getattr(config, 'use_rec_loss', True)

        # Mamba hyperparams
        d_state = getattr(config, 'd_state', 16)
        d_conv = getattr(config, 'd_conv', 4)
        expand = getattr(config, 'expand', 2)
        dropout = getattr(config, 'dropout', 0.1)
        e_layers = getattr(config, 'e_layers', 2)

        self.revin = RevIN(self.enc_in)

        self.patch_embed = PatchEmbedding(
            self.patch_len, self.enc_in, self.dynamic_dim, dropout)

        self.encoder = MambaEncoder(
            d_model=self.dynamic_dim, n_layers=e_layers,
            freq=self.freq, step=self.step,
            bidirectional=self.bidirectional,
            d_state=d_state, d_conv=d_conv, expand=expand, dropout=dropout)

        self.decoder = MLPDecoder(
            self.dynamic_dim, self.patch_len, self.enc_in,
            config.hidden_dim, config.hidden_layers)

        self.rec_decoder = MLP(
            self.dynamic_dim, self.patch_len * self.enc_in,
            config.hidden_dim, config.hidden_layers)

    def encode(self, x):
        B, L, C = x.shape
        x = self.revin(x, 'norm')
        patches = self.patch_embed(x, self.freq, self.padding_len)
        z_mu, z_logvar, latent_rec, prior_dist = self.encoder(patches)

        x_rec = self.rec_decoder(latent_rec)
        x_rec = x_rec.reshape(B, self.freq, self.patch_len, self.enc_in)
        x_rec = x_rec.reshape(B, -1, self.enc_in)[:, :self.input_len, :]

        return x_rec, z_mu, prior_dist

    def decode(self, x_rec, z):
        x_rec = self.revin(x_rec, 'denorm')
        post_dist = self.decoder(z, self.step, self.pred_len, self.revin)
        return x_rec, post_dist

    def forward(self, x):
        x_rec, z_mu, prior_dist = self.encode(x)
        z_sample = prior_dist.rsample()
        x_rec, post_dist = self.decode(x_rec, z_sample)
        return x_rec, prior_dist, post_dist

    @torch.no_grad()
    def sample(self, x, num_samples):
        x_rec, z_mu, _ = self.encode(x)
        dist_list, sample_list = [], []

        for _ in range(self.config.sample_schedule):
            t = z_mu + torch.randn_like(z_mu)
            _, post_dist = self.decode(x_rec, t)
            dist_list.append(post_dist)

        cnt = 0
        k = num_samples // self.config.sample_schedule
        for idx, dist in enumerate(dist_list):
            n = k if idx < self.config.sample_schedule - 1 else num_samples - cnt
            sample_list.append(dist.rsample(sample_shape=(n,)))
            cnt += n

        if num_samples == self.config.sample_schedule:
            sample_list = [d.loc.unsqueeze(0) for d in dist_list]

        return torch.cat(sample_list, dim=0)
