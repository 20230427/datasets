"""
Building blocks for Mamba-VAE.
- BidirectionalMambaBlock: non-causal sequence processing
- UnidirectionalMambaBlock: causal (for ablation)
- PatchEmbedding: time series → patch tokens
- MLP: general-purpose feedforward network
"""

import torch
import torch.nn as nn
from mamba_ssm import Mamba


class BidirectionalMambaBlock(nn.Module):
    def __init__(self, d_model, d_state=16, d_conv=4, expand=2, dropout=0.1):
        super().__init__()
        self.norm = nn.LayerNorm(d_model)
        self.mamba_fwd = Mamba(d_model=d_model, d_state=d_state, d_conv=d_conv, expand=expand)
        self.mamba_bwd = Mamba(d_model=d_model, d_state=d_state, d_conv=d_conv, expand=expand)
        self.fusion = nn.Linear(d_model * 2, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        residual = x
        x = self.norm(x)
        out_fwd = self.mamba_fwd(x)
        out_bwd = torch.flip(self.mamba_bwd(torch.flip(x, [1])), [1])
        out = self.fusion(torch.cat([out_fwd, out_bwd], dim=-1))
        return residual + self.dropout(out)


class UnidirectionalMambaBlock(nn.Module):
    def __init__(self, d_model, d_state=16, d_conv=4, expand=2, dropout=0.1):
        super().__init__()
        self.norm = nn.LayerNorm(d_model)
        self.mamba = Mamba(d_model=d_model, d_state=d_state, d_conv=d_conv, expand=expand)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        residual = x
        out = self.mamba(self.norm(x))
        return residual + self.dropout(out)


class PatchEmbedding(nn.Module):
    def __init__(self, patch_len, n_vars, d_model, dropout=0.1):
        super().__init__()
        self.patch_len = patch_len
        self.proj = nn.Linear(patch_len * n_vars, d_model)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, freq, padding_len):
        B, L, C = x.shape
        x_padded = torch.cat((x[:, L - padding_len:, :], x), dim=1)
        chunks = x_padded.chunk(freq, dim=1)
        patches = torch.stack(chunks, dim=1).reshape(B, freq, -1)
        return self.dropout(self.norm(self.proj(patches)))


class MLP(nn.Module):
    def __init__(self, f_in, f_out, hidden_dim=128, hidden_layers=2, dropout=0.05):
        super().__init__()
        layers = [nn.Linear(f_in, hidden_dim), nn.ReLU(), nn.Dropout(dropout)]
        for _ in range(hidden_layers - 2):
            layers += [nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Dropout(dropout)]
        layers += [nn.Linear(hidden_dim, f_out)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)
