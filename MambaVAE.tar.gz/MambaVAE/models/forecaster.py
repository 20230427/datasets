"""
ProbTS Forecaster wrapper for Mamba-VAE.
Bridges MambaVAE model with ProbTS training/evaluation.
"""

import torch
import torch.nn.functional as F
from einops import rearrange

from probts import Forecaster
from models.mamba_vae import MambaVAE


class ConvertedParams:
    def __init__(self, params):
        for key, value in params.items():
            setattr(self, key, value)


class MambaVAEModel(Forecaster):
    def __init__(
        self,
        # Architecture
        dynamic_dim=256,
        e_layers=2,
        patch_len=24,
        hidden_layers=3,
        hidden_dim=256,
        dropout=0.1,
        # VAE
        weight_beta=0.001,
        sample_schedule=20,
        # Mamba
        d_state=16,
        d_conv=4,
        expand=2,
        # Ablation
        bidirectional=True,
        use_rec_loss=True,
        # Unused (kept for yaml compatibility)
        d_model=256,
        d_ff=256,
        activation='relu',
        n_heads=4,
        factor=3,
        multistep=True,
        init_kalman='identity',
        init_koopman='both',
        **kwargs
    ):
        super().__init__(**kwargs)

        config = ConvertedParams(kwargs)
        config.seq_len = self.context_length
        config.pred_len = self.prediction_length
        config.n_vars = self.input_size
        config.dynamic_dim = dynamic_dim
        config.e_layers = e_layers
        config.patch_len = patch_len
        config.hidden_layers = hidden_layers
        config.hidden_dim = hidden_dim
        config.dropout = dropout
        config.d_state = d_state
        config.d_conv = d_conv
        config.expand = expand
        config.bidirectional = bidirectional
        config.use_rec_loss = use_rec_loss
        config.sample_schedule = sample_schedule

        self.weight_beta = weight_beta
        self.use_rec_loss = use_rec_loss
        self.model = MambaVAE(config)

    def forward(self, input):
        return self.model(input)

    def kld_loss(self, dist):
        mu_q = dist.loc
        cov_q = dist.covariance_matrix
        log_det_q = torch.linalg.slogdet(cov_q)[1]
        trace_q = torch.einsum('btii->bt', cov_q)
        mu_term = torch.sum(mu_q ** 2, dim=-1)
        latent_dim = mu_q.size(-1)
        kld = 0.5 * (trace_q + mu_term - latent_dim - log_det_q)
        return kld.mean()

    def loss(self, batch_data, threshold=1e2):
        self.model.train()
        input = batch_data.past_target_cdf[:, -self.context_length:, :]
        target = batch_data.future_target_cdf

        rec, prior_dist, post_dist = self.forward(input)

        # Point prediction metrics (for monitoring)
        with torch.no_grad():
            pred_mean = post_dist.loc
            self._train_mse = F.mse_loss(pred_mean, target).item()
            self._train_mae = F.l1_loss(pred_mean, target).item()

        rec_loss = F.mse_loss(post_dist.loc, target)
        if self.use_rec_loss:
            rec_loss = rec_loss + F.mse_loss(rec, input)

        post_loss = -post_dist.log_prob(target).mean()
        kld_loss = self.kld_loss(prior_dist)

        weight_alpha = 1 if post_loss < threshold else 0
        return rec_loss + weight_alpha * post_loss + self.weight_beta * kld_loss

    def sample_from_distribution(self, input, num_samples):
        samples = self.model.sample(input, num_samples)
        return rearrange(samples, 'n b l c -> b n l c')

    def forecast(self, batch_data, num_samples=None):
        self.model.eval()
        input = batch_data.past_target_cdf[:, -self.context_length:, :]
        with torch.no_grad():
            if num_samples is not None:
                return self.sample_from_distribution(input, num_samples)
            return None
