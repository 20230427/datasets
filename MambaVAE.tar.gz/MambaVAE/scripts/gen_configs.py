"""Generate YAML configs for all datasets. Run once: python scripts/gen_configs.py"""
import os

TEMPLATE = """seed_everything: 1
trainer:
  accelerator: gpu
  devices: 1
  strategy: auto
  max_epochs: {max_epochs}
  use_distributed_sampler: false
  limit_train_batches: 100
  log_every_n_steps: 1
  check_val_every_n_epoch: 1
  default_root_dir: ./results
  accumulate_grad_batches: 1
  gradient_clip_val: 0.5
model:
  forecaster:
    class_path: models.forecaster.MambaVAEModel
    init_args:
      dynamic_dim: {dynamic_dim}
      d_model: {dynamic_dim}
      d_ff: 256
      e_layers: {e_layers}
      dropout: {dropout}
      activation: relu
      n_heads: 4
      factor: 3
      patch_len: {patch_len}
      multistep: true
      hidden_layers: 3
      hidden_dim: 256
      weight_beta: {weight_beta}
      sample_schedule: {sample_schedule}
      d_state: {d_state}
      d_conv: 4
      expand: 2
      bidirectional: true
      use_rec_loss: true
  num_samples: 100
  learning_rate: {lr}
  quantiles_num: 20
data:
  data_manager:
    class_path: probts.data.data_manager.DataManager
    init_args:
      dataset: {dataset_id}
      context_length: {context_length}
      split_val: true
      scaler: standard
  batch_size: {batch_size}
  test_batch_size: {test_batch_size}
  num_workers: 8
"""

# (dataset_id, ctx, dim, layers, patch, bs, tbs, lr, beta, epochs, d_state, dropout, sample_schedule)
DATASETS = {
    'etth1':       ('etth1',            96, 256, 2, 24, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'etth2':       ('etth2',            96, 256, 2, 24, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'ettm1':       ('ettm1',            96, 256, 2, 24, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'ettm2':       ('ettm2',            96, 256, 2, 24, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'weather':     ('weather',          96, 256, 2, 24, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'exchange':    ('exchange_rate',    96, 256, 2, 24, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'ili':         ('national_illness', 36, 256, 2, 12, 64, 32, 0.001, 0.001, 50, 16, 0.1, 20),
    'electricity': ('electricity',      96, 256, 3, 24,  8,  8, 0.0005, 0.001, 50, 16, 0.1, 5),
    'traffic':     ('traffic',          96, 256, 3, 24,  4,  4, 0.0005, 0.001, 50, 16, 0.1, 5),
}

os.makedirs('config/ltsf', exist_ok=True)
for name, (did, ctx, dim, el, pl, bs, tbs, lr, beta, ep, ds, do, ss) in DATASETS.items():
    cfg = TEMPLATE.format(
        dataset_id=did, context_length=ctx, dynamic_dim=dim, e_layers=el,
        patch_len=pl, batch_size=bs, test_batch_size=tbs, lr=lr,
        weight_beta=beta, max_epochs=ep, d_state=ds, dropout=do, sample_schedule=ss)
    path = f'config/ltsf/{name}.yaml'
    with open(path, 'w') as f:
        f.write(cfg)
    print(f'  Created {path}')
print('Done.')
