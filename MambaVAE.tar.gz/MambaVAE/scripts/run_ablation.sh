#!/bin/bash
# Ablation study on ETTh1 horizon=720
# Usage: bash scripts/run_ablation.sh <DATA_PATH>

DATA_PATH=${1:-./datasets/ETT-small/}
H=720
CFG=config/ltsf/etth1.yaml

echo "============================================"
echo "Mamba-VAE Ablation Study (ETTh1, h=${H})"
echo "============================================"

# 1. Bidirectional vs Unidirectional
for bi in true false; do
    echo ">>> bidirectional=${bi}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.bidirectional ${bi} \
        --trainer.default_root_dir ./logs/abl_bidir${bi}_${H}/
done

# 2. With vs Without L_Rec
for rec in true false; do
    echo ">>> use_rec_loss=${rec}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.use_rec_loss ${rec} \
        --trainer.default_root_dir ./logs/abl_rec${rec}_${H}/
done

# 3. Encoder depth
for l in 1 2 3 4; do
    echo ">>> e_layers=${l}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.e_layers ${l} \
        --trainer.default_root_dir ./logs/abl_layers${l}_${H}/
done

# 4. SSM state dimension
for d in 8 16 32; do
    echo ">>> d_state=${d}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.d_state ${d} \
        --trainer.default_root_dir ./logs/abl_dstate${d}_${H}/
done

# 5. Patch length
for p in 12 24 48; do
    echo ">>> patch_len=${p}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.patch_len ${p} \
        --trainer.default_root_dir ./logs/abl_patch${p}_${H}/
done

# 6. KLD weight
for b in 0.0001 0.001 0.01; do
    echo ">>> weight_beta=${b}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.weight_beta ${b} \
        --trainer.default_root_dir ./logs/abl_beta${b}_${H}/
done

# 7. Dynamic dim
for dim in 128 256 512; do
    echo ">>> dynamic_dim=${dim}"
    python run.py --config ${CFG} \
        --data.data_manager.init_args.path ${DATA_PATH} \
        --data.data_manager.init_args.prediction_length ${H} \
        --model.forecaster.init_args.dynamic_dim ${dim} \
        --trainer.default_root_dir ./logs/abl_dim${dim}_${H}/
done

echo "============================================"
echo "ALL ABLATIONS DONE"
echo "============================================"
