#!/bin/bash
# Full benchmark: all 9 datasets, all horizons
# Usage: bash scripts/run_benchmark.sh <DATA_ROOT>
# Example: bash scripts/run_benchmark.sh ./datasets

DATA_ROOT=${1:-./datasets}

echo "============================================"
echo "Mamba-VAE Full Benchmark"
echo "Data root: ${DATA_ROOT}"
echo "============================================"

# ETT series
for ds in etth1 etth2 ettm1 ettm2; do
    for h in 96 192 336 720; do
        echo ">>> ${ds} h=${h}"
        python run.py --config config/ltsf/${ds}.yaml \
            --data.data_manager.init_args.path ${DATA_ROOT}/ETT-small/ \
            --data.data_manager.init_args.prediction_length ${h} \
            --trainer.default_root_dir ./logs/bench_${ds}_${h}/
    done
done

# Weather
for h in 96 192 336 720; do
    echo ">>> weather h=${h}"
    python run.py --config config/ltsf/weather.yaml \
        --data.data_manager.init_args.path ${DATA_ROOT}/weather/ \
        --data.data_manager.init_args.prediction_length ${h} \
        --trainer.default_root_dir ./logs/bench_weather_${h}/
done

# Exchange
for h in 96 192 336 720; do
    echo ">>> exchange h=${h}"
    python run.py --config config/ltsf/exchange.yaml \
        --data.data_manager.init_args.path ${DATA_ROOT}/exchange_rate/ \
        --data.data_manager.init_args.prediction_length ${h} \
        --trainer.default_root_dir ./logs/bench_exchange_${h}/
done

# ILI (context=36, special horizons)
for h in 24 36 48 60; do
    echo ">>> ili h=${h}"
    python run.py --config config/ltsf/ili.yaml \
        --data.data_manager.init_args.path ${DATA_ROOT}/illness/ \
        --data.data_manager.init_args.prediction_length ${h} \
        --trainer.default_root_dir ./logs/bench_ili_${h}/
done

# Electricity (high-dim)
for h in 96 192 336 720; do
    echo ">>> electricity h=${h}"
    python run.py --config config/ltsf/electricity.yaml \
        --data.data_manager.init_args.path ${DATA_ROOT}/electricity/ \
        --data.data_manager.init_args.prediction_length ${h} \
        --trainer.default_root_dir ./logs/bench_electricity_${h}/
done

# Traffic (high-dim)
for h in 96 192 336 720; do
    echo ">>> traffic h=${h}"
    python run.py --config config/ltsf/traffic.yaml \
        --data.data_manager.init_args.path ${DATA_ROOT}/traffic/ \
        --data.data_manager.init_args.prediction_length ${h} \
        --trainer.default_root_dir ./logs/bench_traffic_${h}/
done

echo "============================================"
echo "ALL BENCHMARKS DONE"
echo "============================================"
