# Mamba-VAE

Bidirectional Mamba-based Variational AutoEncoder for Probabilistic Time Series Forecasting.

## Setup

```bash
# 1. Install ProbTS (from K2VAE repo)
git clone https://github.com/decisionintelligence/K2VAE.git
cd K2VAE && pip install . --no-deps && pip uninstall -y k2vae && cd ..

# 2. Link ProbTS framework
ln -s $(pwd)/K2VAE/probts $(pwd)/probts

# 3. Generate configs for all datasets
python scripts/gen_configs.py

# 4. Run on ETTh1
python run.py --config config/ltsf/etth1.yaml \
    --data.data_manager.init_args.path ./datasets/ETT-small/ \
    --data.data_manager.init_args.prediction_length 720 \
    --trainer.default_root_dir ./logs/etth1_720/
```

## Full benchmark
```bash
bash scripts/run_benchmark.sh ./datasets
```

## Ablation study
```bash
bash scripts/run_ablation.sh ./datasets/ETT-small/
```
