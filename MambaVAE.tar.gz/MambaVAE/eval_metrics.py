"""
Standalone evaluation script.
Computes normalized MAE and MSE (the 0.3-0.5 scale values reported in papers).

Usage:
    python eval_metrics.py --dataset etth1 --pred_len 720 --data_path ./datasets/ETT-small/

This script:
    1. Loads the dataset with StandardScaler (same as training)
    2. Runs the model to get predictions
    3. Computes MAE/MSE on NORMALIZED data (before inverse_transform)
    4. Reports both normalized and raw-scale metrics
"""

import argparse
import os
import sys
import torch
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def load_dataset(dataset, data_path, seq_len=96, pred_len=720):
    """Load dataset and return normalized train/test splits."""

    # Dataset file mapping
    file_map = {
        'etth1': 'ETTh1.csv', 'etth2': 'ETTh2.csv',
        'ettm1': 'ETTm1.csv', 'ettm2': 'ETTm2.csv',
        'weather': 'weather.csv',
        'electricity': 'electricity.csv',
        'exchange_rate': 'exchange_rate.csv',
        'traffic': 'traffic.csv',
        'national_illness': 'national_illness.csv',
    }

    # Split ratios (standard benchmark splits)
    split_map = {
        'etth1': (0.6, 0.2, 0.2), 'etth2': (0.6, 0.2, 0.2),
        'ettm1': (0.6, 0.2, 0.2), 'ettm2': (0.6, 0.2, 0.2),
        'weather': (0.7, 0.1, 0.2),
        'electricity': (0.7, 0.1, 0.2),
        'exchange_rate': (0.7, 0.1, 0.2),
        'traffic': (0.7, 0.1, 0.2),
        'national_illness': (0.7, 0.1, 0.2),
    }

    filename = file_map.get(dataset, f'{dataset}.csv')
    filepath = os.path.join(data_path, filename)

    df = pd.read_csv(filepath)
    # Drop date column if exists
    if 'date' in df.columns:
        df = df.drop(columns=['date'])

    data = df.values.astype(np.float32)
    n = len(data)

    train_ratio, val_ratio, test_ratio = split_map.get(dataset, (0.7, 0.1, 0.2))
    train_end = int(n * train_ratio)
    val_end = int(n * (train_ratio + val_ratio))

    # Fit scaler on training data only
    scaler = StandardScaler()
    scaler.fit(data[:train_end])

    # Transform all data
    data_norm = scaler.transform(data)

    # Extract test set windows
    test_data = data_norm[val_end:]

    windows_x, windows_y = [], []
    for i in range(len(test_data) - seq_len - pred_len + 1):
        windows_x.append(test_data[i:i + seq_len])
        windows_y.append(test_data[i + seq_len:i + seq_len + pred_len])

    X = np.stack(windows_x)  # [N, seq_len, C]
    Y = np.stack(windows_y)  # [N, pred_len, C]

    return X, Y, scaler


def compute_metrics(pred, true):
    """Compute MAE and MSE on the given arrays."""
    mae = np.mean(np.abs(pred - true))
    mse = np.mean((pred - true) ** 2)
    return mae, mse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='etth1')
    parser.add_argument('--data_path', type=str, default='./datasets/ETT-small/')
    parser.add_argument('--seq_len', type=int, default=96)
    parser.add_argument('--pred_len', type=int, default=720)
    parser.add_argument('--batch_size', type=int, default=32)
    args = parser.parse_args()

    print(f"Dataset: {args.dataset}, seq_len: {args.seq_len}, pred_len: {args.pred_len}")

    # Load normalized data
    X, Y, scaler = load_dataset(args.dataset, args.data_path, args.seq_len, args.pred_len)
    print(f"Test samples: {len(X)}, Variables: {X.shape[2]}")

    X_tensor = torch.FloatTensor(X).cuda()
    Y_tensor = torch.FloatTensor(Y).cuda()

    # Load model
    from models.mamba_vae import MambaVAE

    class Config:
        pass

    config = Config()
    config.seq_len = args.seq_len
    config.pred_len = args.pred_len
    config.n_vars = X.shape[2]
    config.patch_len = 24
    config.dynamic_dim = 256
    config.e_layers = 2
    config.hidden_dim = 256
    config.hidden_layers = 3
    config.dropout = 0.1
    config.d_state = 16
    config.d_conv = 4
    config.expand = 2
    config.bidirectional = True
    config.use_rec_loss = True
    config.sample_schedule = 20

    model = MambaVAE(config).cuda().eval()

    # Run inference batch by batch
    all_preds = []
    with torch.no_grad():
        for i in range(0, len(X_tensor), args.batch_size):
            batch_x = X_tensor[i:i + args.batch_size]
            x_rec, z_mu, prior_dist = model.encode(batch_x)
            _, post_dist = model.decode(x_rec, z_mu)
            pred = post_dist.loc  # [B, pred_len, C]
            all_preds.append(pred.cpu().numpy())

    preds = np.concatenate(all_preds, axis=0)  # [N, pred_len, C]
    trues = Y  # [N, pred_len, C]

    # Metrics on NORMALIZED data (this is what papers report)
    norm_mae, norm_mse = compute_metrics(preds, trues)

    # Metrics on RAW data (for reference)
    preds_raw = scaler.inverse_transform(preds.reshape(-1, preds.shape[-1])).reshape(preds.shape)
    trues_raw = scaler.inverse_transform(trues.reshape(-1, trues.shape[-1])).reshape(trues.shape)
    raw_mae, raw_mse = compute_metrics(preds_raw, trues_raw)

    print(f"\n{'='*50}")
    print(f"Results: {args.dataset}, horizon={args.pred_len}")
    print(f"{'='*50}")
    print(f"  Normalized (paper-scale):")
    print(f"    MSE: {norm_mse:.4f}")
    print(f"    MAE: {norm_mae:.4f}")
    print(f"  Raw scale:")
    print(f"    MSE: {raw_mse:.4f}")
    print(f"    MAE: {raw_mae:.4f}")
    print(f"{'='*50}")


if __name__ == "__main__":
    main()
