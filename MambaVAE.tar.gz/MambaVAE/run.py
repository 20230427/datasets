"""
Mamba-VAE entry point.
Reuses ProbTS framework for data loading, training, and evaluation.
"""

import sys
import os
import logging

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lightning.pytorch.cli import LightningCLI
from models.forecast_module import MambaVAEForecastModule
from probts.data import ProbTSDataModule

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ProbTSCli(LightningCLI):
    def add_arguments_to_parser(self, parser):
        parser.link_arguments("data.data_manager", "model.data_manager")

    def run(self):
        if self.subcommand is None or self.subcommand == "fit":
            self.trainer.fit(model=self.model, datamodule=self.datamodule)
            ckpt = self.trainer.checkpoint_callback.best_model_path if self.trainer.checkpoint_callback else None
            if ckpt:
                logger.info(f"Loading best checkpoint from {ckpt}")
            self.trainer.test(model=self.model, datamodule=self.datamodule, ckpt_path=ckpt)
        elif self.subcommand == "test":
            self.trainer.test(model=self.model, datamodule=self.datamodule)


if __name__ == "__main__":
    cli = ProbTSCli(
        MambaVAEForecastModule,
        ProbTSDataModule,
        subcommand_metavar=None,
        save_config_kwargs={"overwrite": True},
    )
    cli.run()
